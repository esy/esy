
import path = require('path')
import fs = require('mz/fs')
import * as api from '@andreypopp/pnpm'
import {Resolution} from '@andreypopp/pnpm/lib/resolve'
import execa = require('execa')
import mkdirp from '@andreypopp/pnpm/lib/fs/mkdirp';
import resolveFromOpam, {readPackageJson, OpamResolution} from './resolveFromOpam'
import {fetchFromTarball} from '@andreypopp/pnpm/lib/install/fetchResolution';

let installation = api.installPkgs(process.argv.slice(2), {
  storePath: path.join(process.env.HOME, '.esy', '_fetch'),
  preserveSymlinks: false,
  lifecycle: {

    packageWillResolve: async (spec, opts) => {
      switch (spec.type) {
        case 'range':
        case 'version':
        case 'tag': {
          if (spec.scope === '@opam') {
            return resolveFromOpam(spec, opts)
          }
        }
      }
      return null
    },

    packageWillFetch: async (target, resolution, opts) => {
      const opamResolution = resolution as OpamResolution

      if (opamResolution.opam == null || opamResolution.type !== 'tarball') {
        return false
      }

      console.log('xxx')
      await mkdirp(target)
      console.log('xxx')
      await fetchFromTarball(target, {tarball: opamResolution.tarball}, opts)
      console.log('xxx')

      return true
    },

    packageDidFetch: async (target, resolution) => {
      const opamResolution = resolution as OpamResolution

      if (opamResolution.opam == null) {
        return
      }

      const {name, version} = opamResolution.opam
      const packageRecord = await readPackageJson(name)
      const packageJson = packageRecord.versions[version]

      if (packageJson.opam.patch) {
        const patchFilename = path.join(target, '_esy_patch')
        await fs.writeFile(patchFilename, packageJson.opam.patch, 'utf8')
        await execa.shell('patch -p1 < _esy_patch', {cwd: target})
      }

      const filename = path.join(target, 'package.json')
      packageJson['_resolved'] = opamResolution.id
      await fs.writeFile(filename, JSON.stringify(packageJson, null, 2), 'utf8')
    },
  }
});

installation.then(
  () => console.log('OK'),
  (err) => console.error(err)
);
